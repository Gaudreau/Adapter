package com.example.hadleigh.cursoradapter.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


/**
 * Created by Gaudreau on 12/03/2017.
 */
public class MyDatabaseHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 2;
    private static final String DATABASE_NAME = "contacts.db";
    public static final String TABLE_NAME = "contacts_list";

    public static final String COLUMN_ID = "_id";



    public static final String COLUMN_ALARMNAME = "alarm_name";

    // SQL for setting switch to be enabled
    public static final String COLUMN_SWITCH_STATE = "switch_state";


    // Standard constructor
    public MyDatabaseHandler(Context context, String name,
                             SQLiteDatabase.CursorFactory factory, int version) {


        super(context, DATABASE_NAME, factory, DATABASE_VERSION);


    }



    @Override
    public void onCreate(SQLiteDatabase db) {

        String create_contacts_table = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_ALARMNAME + " TEXT," +
                COLUMN_SWITCH_STATE + " TEXT)";


        db.execSQL(create_contacts_table);


    }

    // This method is called when the database needs updating.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);

    }






    public void addProduct(ContactDetails contactDetails) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_ALARMNAME, contactDetails.getAlarmName());
        values.put(COLUMN_SWITCH_STATE,contactDetails.getSwitchState());




        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    public Cursor setInfo (){



        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("select * from contacts_list",null);

        if (cursor != null) {
            cursor.moveToFirst();
            return cursor;
        }
        else
        {
            return null;
        }
    }











}
