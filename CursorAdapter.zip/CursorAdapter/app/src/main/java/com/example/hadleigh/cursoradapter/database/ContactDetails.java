package com.example.hadleigh.cursoradapter.database;

/**
 * Created by Gaudreau on 12/03/2017.
 */
public class ContactDetails {








    private String alarmName;
    private String switchState;


    public ContactDetails(){


    }
    public ContactDetails(String alarmName,String switchState) {


        this.alarmName = alarmName;
        this.switchState = switchState;



    }



    public String getSwitchState() {return switchState;}

    public void setSwitchState(String switchState) {this.switchState = switchState;}



    public String getAlarmName() {return alarmName;}

    public void setAlarmName(String alarmName) {this.alarmName = alarmName;}








}
