package com.example.hadleigh.cursoradapter;

import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.widget.ListView;

import com.example.hadleigh.cursoradapter.adapter.ContactsRecyclerAdapter;
import com.example.hadleigh.cursoradapter.database.MyDatabaseHandler;

public class SecondActivity extends AppCompatActivity {






    ListView alarmListView;


    MyDatabaseHandler databaseHandler;
    ItemTouchHelper itemTouchHelper;


    RecyclerView recyclerView;
    ContactsRecyclerAdapter contactsRecyclerAdapter;

    private static final String LIST_STATE = "listState";
    private Parcelable mListState = null;


    LinearLayoutManager linearLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contact_list_activity);

        recyclerView = (RecyclerView) findViewById(R.id.recycler_view_layout);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());




        recyclerView.setLayoutManager(layoutManager);


        databaseHandler = new MyDatabaseHandler(getApplicationContext(), null, null, 1);


        contactsRecyclerAdapter = new ContactsRecyclerAdapter(getApplicationContext(), databaseHandler.setInfo());

        recyclerView.setAdapter(contactsRecyclerAdapter);
        recyclerView.setItemAnimator(null);




        linearLayoutManager = new LinearLayoutManager((getApplicationContext()));
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setHasFixedSize(true);

















    }
}
