package com.example.hadleigh.cursoradapter.adapter;

import android.content.Context;
import android.database.Cursor;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.CursorAdapter;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.example.hadleigh.cursoradapter.R;


/**
 * Created by Hadleigh on 31/05/2017.
 */

public class ContactsRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {




    CursorAdapter mCursorAdapter;
    Context mContext;
    Cursor mCursor;

    private View rootView;



    int position;

    Viewholder viewholder;




    public ContactsRecyclerAdapter(Context context, final Cursor cursor) {



        mContext = context;

        mCursorAdapter = new CursorAdapter(mContext, cursor, 0) {
            @Override
            public View newView(Context context, Cursor cursor, ViewGroup parent) {

                rootView = LayoutInflater.from(context).inflate(R.layout.contacts, parent, false);

                return rootView;


            }

            @Override
            public void bindView(View view, final Context context, final Cursor cursor) {





                mCursor = cursor;



                viewholder = new Viewholder(view);



                String name = cursor.getString(cursor.getColumnIndexOrThrow("alarm_name"));
                final String switchState = cursor.getString(cursor.getColumnIndexOrThrow("switch_state"));




                position = cursor.getPosition();

                viewholder.custom_Name.setText(name);


                viewholder.custom_alarm_switch.setChecked(Boolean.valueOf(switchState));
                viewholder.custom_alarm_switch.setTag(position);


                cursor.moveToPosition(position);







                changeSwitchState();

            }
        };



    }

    public void changeSwitchState(){





        viewholder.custom_alarm_switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                Integer pos = (Integer) buttonView.getTag();



                mCursor.moveToPosition(pos);


                if (buttonView.isChecked()){



                    Toast.makeText(mContext, "CONTACT SELECTED", Toast.LENGTH_SHORT).show();
                } else {




                    Toast.makeText(mContext, "CONTACT DESELECTED", Toast.LENGTH_SHORT).show();
                }

            }
        });





    }

    public static class Viewholder extends RecyclerView.ViewHolder {


        TextView custom_Name;
        Switch custom_alarm_switch;




        public Viewholder(View itemView) {
            super(itemView);


            custom_alarm_switch = (Switch) itemView.findViewById(R.id.selectedContacts);
            custom_Name = (TextView) itemView.findViewById(R.id.custom_Name);



        }


    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = mCursorAdapter.newView(mContext, mCursorAdapter.getCursor(), parent);

        return new Viewholder(view);


    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        mCursorAdapter.getCursor().moveToPosition(position);



        mCursorAdapter.bindView(holder.itemView, mContext, mCursorAdapter.getCursor());





    }





    @Override
    public int getItemCount() {


        return mCursorAdapter.getCount();
    }







    }

















